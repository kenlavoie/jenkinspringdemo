#!/bin/bash -x

pip install -U pip \
&& pip install -r requirements.txt \
&& pip install psycopg2