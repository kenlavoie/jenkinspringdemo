#!/bin/bash
<<<<<<< Updated upstream

sleep 30

pip install -U pip \
&& pip install -r requirements.txt \
   pip install psycopg2
=======

sleep 30s

pip3 install -r requirements.txt 
>>>>>>> Stashed changes
